<div>
    <?php echo e($slot); ?>


    
    <footer class="text-center text-sm text-gray-500 mt-8 mb-4">
        &copy; <?php echo e(date('Y')); ?> PT. Samana Jaya Propertindo.
    </footer>
</div><?php /**PATH C:\xampp\htdocs\samarent-app\resources\views\vendor\filament\components\layouts\app.blade.php ENDPATH**/ ?>