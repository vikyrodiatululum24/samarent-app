<?php if(!empty($getState()) && is_iterable($getState())): ?>
    <p class="label mb-2">Foto Tambahan</p>
    <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
        <?php $__currentLoopData = $getState(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex flex-col items-center gap-2 mb-2">
                <img src="<?php echo e(asset('storage/' . $image)); ?>" class="object-cover rounded-lg shadow-md" alt="Foto Tambahan" />
                <a href="<?php echo e(asset('storage/' . $image)); ?>" download class="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition">
                    Download
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php else: ?>
    <p class="text-gray-500">Tidak ada foto tambahan.</p>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\samarent-app\resources\views\filament\components\foto-tambahan.blade.php ENDPATH**/ ?>