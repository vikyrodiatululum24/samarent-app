<p class="mb-2">Foto Unit</p>
<div class="flex flex-col items-center gap-2">
    <?php if($getState()): ?>
        <img src="<?php echo e(asset('storage/' . $getState())); ?>" class="object-cover rounded shadow" alt="Foto Unit">
        <a href="<?php echo e(asset('storage/' . $getState())); ?>" download class="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition">
            Download
        </a>
    <?php else: ?>
        <p class="text-gray-500">Foto unit tidak tersedia.</p>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\samarent-app\resources\views\filament\components\foto-unit.blade.php ENDPATH**/ ?>