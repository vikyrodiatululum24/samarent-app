<?php

namespace App\Filament\Resources\ProsesResource\Pages;

use App\Filament\Resources\ProsesResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateProses extends CreateRecord
{
    protected static string $resource = ProsesResource::class;
}
