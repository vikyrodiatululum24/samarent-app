<footer class="text-center text-sm text-gray-500 mt-8 mb-4">
    &copy; {{ date('Y') }} PT. Samana Jaya Propertindo.
    <br>Developed by <a href="https://www.tiktok.com/@codetech.id" class="text-blue-500 hover:underline">Codetech.id</a>.
</footer>